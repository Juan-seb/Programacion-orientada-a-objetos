
package ProyectCarnet;

import java.lang.reflect.Array;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class AdminCarnet {
    
    String cod;
    Archivo arch;
    
    
    public AdminCarnet(){
        arch=new Archivo();
    }
    
    public Respuesta guardarRegistro(Registro reg){
        
        ArrayList<Registro> Arrayreg=arch.abrir("datos.txt");
        if(Arrayreg==null){
            Arrayreg=new ArrayList();
        }
        for(Registro reg1: Arrayreg){
            
            if(reg1.getCodigo().equals(reg.getCodigo())){//Me pregunta si el elemento del arrayList tiene el mismo codigo que otro elemento
                return new Respuesta(false,"El codigo del carnet esta siendo usado");
            }    
        }
        
        Arrayreg.add(reg);
        
        return new Respuesta(arch.guardar("datos.txt",Arrayreg),"Proceso realizado con exito");       
    }
    
    public void LeerRegistro(){
       
        Registro reg=new Registro();
        
        ArrayList<Registro> Arrayreg=arch.abrir("datos.txt");
        
        if(Arrayreg==null){
             Arrayreg=new ArrayList();//Primero pregunto si esta sola para luego proceder a leer los datos que hay en ella.
        }
        
        for(Registro reg1:Arrayreg){
            JOptionPane.showMessageDialog(null,reg1.getNombre()+"\n"+reg1.getCodigo()+"\n"+reg1.getProyecto()+"\n"+reg1.getUniversidad(),"Datos",0);
        } 
    }
    
    public Respuesta EliminarCarnet(Registro reg){

        ArrayList<Registro> Arrayreg = arch.abrir("datos.txt");
        
        if(Arrayreg==null){
            Arrayreg=new ArrayList();//Creando el array
        }
        
        for (int i = 0; i < Arrayreg.size(); i++) {
  
            if(Arrayreg.get(i).getCodigo().equals(reg.getCodigo())){
                Arrayreg.remove(i);
                return new Respuesta(arch.guardar("datos.txt",Arrayreg),"Se elimino el carnet");       
            }
        }    
        return new Respuesta(false,"Error no encontro el carnet");
    }
    
    
    public int Buscar(Registro reg){
        
    
        ArrayList<Registro> Arrayreg = arch.abrir("datos.txt");
        
        if(Arrayreg==null){
            Arrayreg = new ArrayList();
        }
        
        for(int i=0;i<Arrayreg.size();i++){
            if(Arrayreg.get(i).getCodigo().equals(reg.getCodigo())){
                
                return i;
                
            }
        }
        return 0; 
    }
    
    public Respuesta CorregirCarnet (Registro reg,int index){
        
        ArrayList<Registro> Arrayreg = arch.abrir("datos.txt");
        
        if(Arrayreg==null){
            Arrayreg = new ArrayList();
        }
        Arrayreg.set(index,reg);
        
        return new Respuesta(arch.guardar("datos.txt",Arrayreg),"Proceso realizado con exito"); 
    }
}
 