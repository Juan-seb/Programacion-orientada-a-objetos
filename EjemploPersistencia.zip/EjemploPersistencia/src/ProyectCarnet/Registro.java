package ProyectCarnet;

import java.io.Serializable;

/**
 *
 * @author Usuario
 */
public class Registro implements Serializable {
    
    private String Nombre;
    private String Codigo;
    private String Proyecto;
    private String Universidad;

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getCodigo() {
        return Codigo;
    }

    public void setCodigo(String Codigo) {
        this.Codigo = Codigo;
    }

    public String getProyecto() {
        return Proyecto;
    }

    public void setProyecto(String Email) {
        this.Proyecto = Proyecto;
    }

    public String getUniversidad() {
        return Universidad;
    }

    public void setUniversidad(String Universidad) {
        this.Universidad = Universidad;
    }
    
    public String toString(){
        return "Nombre"+Nombre+"/n"+"Codigo"+Codigo+"/n"+"Proyecto"+Proyecto;
        
    }
}
