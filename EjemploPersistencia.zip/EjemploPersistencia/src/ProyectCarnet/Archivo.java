package ProyectCarnet;

import java.io.EOFException;
import java.io.File;
import java.util.ArrayList;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
public class Archivo {

    public Boolean guardar(String ruta, ArrayList<Registro> arrayReg){//Tipo Boleano, ruta para la persistencia y un array list de tipo Registro
        
        try{
            File f =new File(ruta);//Crea la ruta
            f.delete();
            ObjectOutputStream salida=new ObjectOutputStream(new FileOutputStream(ruta));//Donde voy a escribir el archivo
            salida.writeObject(arrayReg);//Escribe lo del Array
            salida.close();//Cerrar
            return true;
        }catch(IOException e){  
        }
        return null;
    }
    
    public ArrayList<Registro> abrir (String ruta){
        
        try{   
            ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(ruta));//Abrir el archivo
            if(entrada!=null){//Si la entrada es nula entonces no va a leer nada
                ArrayList<Registro> arrayReg=(ArrayList<Registro>) entrada.readObject();//Lee el array
                entrada.close();
                return arrayReg;//Devuelve el array
            }
        }catch(IOException e){
            e.printStackTrace();
        }catch(ClassNotFoundException ex){
            System.out.println("Clase no encontrada");
        }
        return null;
    }        
}
