import java.util.Calendar;

import javax.swing.*;

public class Saludo_generacional {

	private String mensaje;
	private String nombre;
	private double edad;
	
	public String getMensaje() {
		return mensaje;
	}
	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public double getEdad() {
		return edad;
	}
	public void setEdad(double edad) {
		this.edad = edad;
	}
	
	public void mensaje__edad() {
		
		ImageIcon imagen = new ImageIcon("./img/Edad.jpg");
		JTextField cnum=new JTextField();
		JTextField nombres=new JTextField();
		String datos="\nPor favor ingrese su edad: \n";
		String nom="\nPor favor ingrese su nombre: \n";
		Object inicio[]= {imagen,datos,cnum,nom,nombres};
		
		JOptionPane.showMessageDialog(null, inicio);
		this.edad=Integer.parseInt(cnum.getText());
		String n=nombres.getText();
		this.nombre=n;
	}
	
	public void saludo(){
		int x=0;
		while(x==0) {
			Calendar calendario=Calendar.getInstance();
			int hora=calendario.get(Calendar.HOUR_OF_DAY);
			if((this.edad<=100 && this.edad>=51)&&(hora>=1 && hora<12)) {
				ImageIcon imagen = new ImageIcon("./img/Generacion silenciosa.jpg");
				String sil="\nBuenos d�as se�or"+" "+this.nombre;
				Object obj[]= {imagen,sil};
				JOptionPane.showMessageDialog(null,obj,"Generacion w",JOptionPane.INFORMATION_MESSAGE);
				x=1;
			}
			if((this.edad<=100 && this.edad>=51)&&(hora>=12 && hora<=18)) {
				ImageIcon imagen = new ImageIcon("./img/Generacion silenciosa.jpg");
				String sil="\nBuenas tardes se�or"+" "+this.nombre;
				Object obj[]= {imagen,sil};
				JOptionPane.showMessageDialog(null,obj,"Generacion w",JOptionPane.INFORMATION_MESSAGE);
				x=1;
			}
			if((this.edad<=100 && this.edad>=51)&&(hora>=18 && hora<=23)) {
				ImageIcon imagen = new ImageIcon("./img/Generacion silenciosa.jpg");
				String sil="\nBuenas noches se�or"+" "+this.nombre;
				Object obj[]= {imagen,sil};
				JOptionPane.showMessageDialog(null,obj,"Generacion w",JOptionPane.INFORMATION_MESSAGE);
				x=1;
			}
			//Generacion de la guayaba
			if((this.edad>=45 && this.edad<=50)&&(hora>=1 && hora<23)) {
				ImageIcon imagen = new ImageIcon("./img/nuclear.jpg");
				String gua="\n�Hola Juan, viste las noticias de la energia nuclear"+" "+this.nombre+ "!";
				Object obje[]= {imagen,gua};
				JOptionPane.showMessageDialog(null,obje,"Generacion de la guayaba",JOptionPane.INFORMATION_MESSAGE);
				x=1;
			}
			//Generacion x
			if((this.edad>=39 && this.edad<=44)&&(hora>=1 && hora<12)) {
				ImageIcon imagen = new ImageIcon("./img/hippies.jpg");
				String x1="\n�Hermosa ma�ana, �Amor y paz!"+" "+this.nombre+ "!";
				Object objet[]= {imagen,x1};
				JOptionPane.showMessageDialog(null,objet,"Generacion x",JOptionPane.INFORMATION_MESSAGE);
				x=1;
			}
			if((this.edad>=39 && this.edad<=44)&&(hora>=12 && hora<16)) {
				ImageIcon imagen = new ImageIcon("./img/hippies.jpg");
				String x1="\n�Hermosa tarde, �Amor y paz!"+" "+this.nombre+ "!";
				Object objet[]= {imagen,x1};
				JOptionPane.showMessageDialog(null,objet,"Generacion x",JOptionPane.INFORMATION_MESSAGE);
				x=1;
			}
				if((this.edad>=39 && this.edad<=44)&&(hora>=16 && hora<23)) {
				ImageIcon imagen = new ImageIcon("./img/hippies.jpg");
				String x1="\n�Hermosa noche, �Amor y paz!"+" "+this.nombre+ "!";
				Object objet[]= {imagen,x1};
				JOptionPane.showMessageDialog(null,objet,"Generacion x",JOptionPane.INFORMATION_MESSAGE);
				x=1;
			}
			//Generacion y	
			if((this.edad>=27 && this.edad<=38)&&(hora>=1 && hora<12)) {
				ImageIcon imagen = new ImageIcon("./img/Generacion y.jpg");
				String x12="\nHola lindo(a), buenos d�as"+" "+this.nombre+ "!";
				Object objeto[]= {imagen,x12};
				JOptionPane.showMessageDialog(null,objeto,"Generacion y",JOptionPane.INFORMATION_MESSAGE);
				x=1;
			}
			if((this.edad>=27 && this.edad<=38)&&(hora>=12 && hora<16)) {
				ImageIcon imagen = new ImageIcon("./img/Generacion y.jpg");
				String x12="\nHola lindo(a), buenas tardes"+" "+this.nombre+ "!";
				Object objeto[]= {imagen,x12};
				JOptionPane.showMessageDialog(null,objeto,"Generacion y",JOptionPane.INFORMATION_MESSAGE);
				x=1;
			}
				if((this.edad>=27 && this.edad<=38)&&(hora>=16 && hora<23)) {
				ImageIcon imagen = new ImageIcon("./img/Generacion y.jpg");
				String x12="\nHola lindo(a), buenas noches"+" "+this.nombre+ "!";
				Object objeto[]= {imagen,x12};
				JOptionPane.showMessageDialog(null,objeto,"Generacion y",JOptionPane.INFORMATION_MESSAGE);
				x=1;
			}
			if((this.edad>=18 && this.edad<=26)&&(hora>=1 && hora<12)) {
				ImageIcon imagen = new ImageIcon("./img/z.jpg");
				String x13="\nSe�or(a)"+" "+this.nombre+" Buenos dias"+ "!";
				Object objetos[]= {imagen,x13};
				JOptionPane.showMessageDialog(null,objetos,"Generacion z",JOptionPane.INFORMATION_MESSAGE);
				x=1;
			}
				if((this.edad>=18 && this.edad<=26)&&(hora>=12 && hora<16)) {
				ImageIcon imagen = new ImageIcon("./img/z.jpg");
				String x13="\nSe�or(a)"+" "+this.nombre+" Buenas tardes"+ "!";
				Object objetos[]= {imagen,x13};
				JOptionPane.showMessageDialog(null,objetos,"Generacion z",JOptionPane.INFORMATION_MESSAGE);
				x=1;
			}
				if((this.edad>=18 && this.edad<=26)&&(hora>=16 && hora<23)) {
				ImageIcon imagen = new ImageIcon("./img/z.jpg");
				String x13="\nSe�or(a)"+" "+this.nombre+" Buenas noches"+ "!";
				Object objetos[]= {imagen,x13};
				JOptionPane.showMessageDialog(null,objetos,"Generacion z",JOptionPane.INFORMATION_MESSAGE);
				x=1;
			}
			if((this.edad>=0 && this.edad<=17)&&(hora>=1 && hora<12)) {
				ImageIcon imagen = new ImageIcon("./img/AA.jpg");
				String x14="\nParce"+" "+this.nombre+" Buenos dias"+ "!";
				Object objetos1[]= {imagen,x14};
				JOptionPane.showMessageDialog(null,objetos1,"Generacion AA",JOptionPane.INFORMATION_MESSAGE);
				x=1;
			}
				if((this.edad>=0 && this.edad<=17)&&(hora>=12 && hora<16)) {
				ImageIcon imagen = new ImageIcon("./img/AA.jpg");
				String x14="\nParce"+" "+this.nombre+" Buenas tardes"+ "!";
				Object objetos1[]= {imagen,x14};
				JOptionPane.showMessageDialog(null,objetos1,"Generacion AA",JOptionPane.INFORMATION_MESSAGE);
				x=1;
			}
				if((this.edad>=0 && this.edad<=17)&&(hora>=16 && hora<23)) {
				ImageIcon imagen = new ImageIcon("./img/AA.jpg");
				String x14="\nParce"+" "+this.nombre+" Buenas noches"+ "!";
				Object objetos1[]= {imagen,x14};
				JOptionPane.showMessageDialog(null,objetos1,"Generacion AA",JOptionPane.INFORMATION_MESSAGE);
				x=1;
			}	
		}
	}
}	

