public class ProgramaBienvenida {
	
	public static void main(String args[]) {

		Saludo_generacional B= new Saludo_generacional();
		B.mensaje__edad();
		B.saludo();
		}
		
}
