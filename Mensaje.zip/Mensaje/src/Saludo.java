import java.awt.*;

import javax.swing.JOptionPane;
public class Saludo {
	
	private String Mensaje;

	public String getMensaje() {
		return Mensaje;
	}


	public void setMensaje(String mensaje) {
		Mensaje = mensaje;
	}

	public  Saludo(String Mensaje) {
		this.Mensaje=Mensaje;
		
	}
	public void Mensaje() {
	
	JOptionPane.showMessageDialog(null, this.Mensaje,"Hola mundo",JOptionPane.QUESTION_MESSAGE);
	}


	
}