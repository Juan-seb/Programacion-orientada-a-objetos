import java.awt.*;
import java.util.Calendar;

import javax.swing.JOptionPane;
public class Saludo_personalizado {
	
	private String Mensaje;
	private String Nombre;

	public String getNombre() {
		return Nombre;
	}


	public void setNombre(String nombre) {
		Nombre = nombre;
	}


	public String getMensaje() {
		return Mensaje;
	}


	public void setMensaje(String mensaje) {
		Mensaje = mensaje;
	}

	public  Saludo_personalizado(String Mensaje, String Nombre) {
		this.Mensaje=Mensaje;
		this.Nombre=Nombre;
	}
	public void Mensaje() {
		Calendar calendario=Calendar.getInstance();
		int hora=calendario.get(Calendar.HOUR_OF_DAY);
		if (hora>=1 && hora<=12) {
			JOptionPane.showMessageDialog(null,"Buenos dias","Bienvenido",JOptionPane.INFORMATION_MESSAGE);
		}
		if (hora>=12 && hora<14) {
			JOptionPane.showMessageDialog(null,"Buenas tardes","Bienvenido",JOptionPane.INFORMATION_MESSAGE);
		}
		if (hora>=14 && hora<=24) {
			JOptionPane.showMessageDialog(null,"Buenos noches","Bienvenid",JOptionPane.INFORMATION_MESSAGE);
		}
		JOptionPane.showMessageDialog(null, this.Mensaje+" "+this.Nombre,"Hola mundo",JOptionPane.QUESTION_MESSAGE);
	}

}
